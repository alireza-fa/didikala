$(document).ready(function(){
$('#click_to_escape').click(function(){

$('#modal-location').attr({"style": 'padding-right: 15px; display: block;'})
});


$('#close').click(function(){
$('#modal-location').attr({"style": ''})
});

});
