SECRET_KEY = 'django-insecure-o+&*$phztf283$)n*==v#y*eyq(z0twc$5(a=x9*g(*#x%uv+r'

DEBUG = True

DB_NAME = 'didikala3'
DB_USER = 'didikala3'
DB_PASS = 'didikala3'
DB_HOST = 'localhost'
DB_PORT = 5432
